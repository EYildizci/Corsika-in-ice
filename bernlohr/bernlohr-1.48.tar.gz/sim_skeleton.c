/* ============================================================================

   Copyright (C) 1997, 1999, ..., 2010  Konrad Bernloehr

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

============================================================================ */

/* ================================================================ */
/**
 * @file sim_skeleton.c
 * @short A (non-functional) skeleton program for reading CORSIKA IACT data.
 *
 * This file contains a (non-functional) skeleton of the telescope simulation.
 * It serves only as an illustration of the essential usage of
 * CORSIKA related eventio functions to read CORSIKA data in
 * eventio format and how some of the required values are extracted.
 * Comment lines with '...' usually indicate that you should fill in
 * relevant code yourself.
 *
 * This file comes with no warranties.
*/
/* ================================================================ */

#include "initial.h"      /* This file includes others as required. */
#include "io_basic.h"     /* This file includes others as required. */
#include "mc_tel.h"
#include "fileopen.h"
#include "atmo.h"
/* ... #include other header files .... */

/** >>>> Change the following limits as appropriate <<<< */
#define MAX_BUNCHES 2500000     /**< The largest no. of bunches that can be handled. */
#define MAX_PHOTOELECTRONS 1000000 /** The largest number of photo-electrons. */
#define MAX_PIXELS 1024       /**< The largest no. of pixels per camers */
#define MAX_TEL 16            /**< The largest no. of telescopes/array. */
#define MAX_ARRAY 100         /**< The largest no. of arrays to be handled */

static double airlightspeed = 29.9792458/1.0002256; /* [cm/ns] at H=2200 m */

/** Refraction index of air as a function of height in km (0km<=h<=8km) */
#define Nair(hkm) (1.+0.0002814*exp(-0.0947982*(hkm)-0.00134614*(hkm)*(hkm)))

#ifndef Nint
#define Nint(x) ((x)>0?(int)((x)+0.5):(int)((x)-0.5))
#endif

/* External functions: */
void atmset_(int *iatmo, double *obslev); /* see atmo.c */
double RandFlat(void); /* Random number generator [0.:1[ */
double atmospheric_transmission (int iwl, double zem, double airmass); /* ... */

/* Dummy replacements for CORSIKA function linked with atmo.c */
double heigh_(double *x) { return 0.; }
double thick_(double *h) { return 0.; }
double rhof_(double *h)  { return 0.; }

/* Trivial implementation of the RandFlat function with constant seeds. */
double RandFlat(void)
{
   static int init_needed = 1;
   if ( init_needed )
   {
      unsigned short s[3] = { 12345, 4321, 7890 };
      seed48(s);
      init_needed = 0;
   }
   return drand48();
}

/* Trivial implementation of atmospheric transmission: fully transparent */
double atmospheric_transmission (int iwl, double zem, double airmass)
{
   return 1.0;
}

/* ------------------- find_max_pos -------------------- */
/*
 *  Find position of maximum in distribution at equidistant positions by
 *  adapting a parabola to the largest entry and its neighbours.
 *
 *  @param y Amplitudes at equidistant positions.
 *  @param n number of positions.
 *
 *  @return -1. (could not find a maximum) or the index to
 *	the maximum position (0. -> first, n-1 -> last position).
*/

double find_max_pos (double *y, int n)
{
   int imax, ic, i;
   double ymax, ym, y_0, yp, a2;
   if ( n < 3 )
      return -1.;
   for (imax=0, ymax=y[0], i=1; i<n; i++)
      if ( y[i] > ymax )
      {
      	 imax = i;
	 ymax = y[i];
      }
   if ( imax < 1 )
      ic = 1;
   else if ( imax >= n-1 )
      ic = n-2;
   else
      ic = imax;
   ym = y[ic-1];
   y_0 = y[ic];
   yp = y[ic+1];
   if ( (a2=yp+ym-2.*y_0) >= 0. ) /* Then there is no maximum */
      return -1.;
   else
      return 0.5*(ym-yp)/a2 + (double)ic;
}

/* Change the following data structures as required: */

/** Options of the simulation passed through to low-level functions. */
struct mc_options
{
   const char *input_fname;    /**< Input file name. */
   long iobuf_max;     /**< Size limit for I/O buffers. */
   int always_with_aweight; /**< Make MCEvent output always with area weights. */
};


/** Basic parameters of the CORSIKA run */

struct mc_run
{
   int run;                /**< Run number. */
   int corsika_version;    /**< CORSIKA version number * 1000. */
   int atmosphere;         /**< Model atmosphere number. */
   double height;          /**< Height of observation level [m] */
   double e_min;           /**< Lower limit of simulated energies [TeV] */
   double e_max;           /**< Upper limit of simulated energies [TeV] */
   double slope;           /**< Spectral index of power-law spectrum */
   double radius;          /**< Radius within which cores are thrown at random. [m] */
   double radius1;         /**< Distance parameter 1 in CSCAT [m] */
   double radius2;         /**< Distance parameter 2 in CSCAT [m] */
   double area;            /**< Area over which offsets may be scattered [m^2]. */
   int num_arrays;         /**< Number of arrays simulated. */
   double theta_min;       /**< Lower limit of zenith angle [degrees] */
   double theta_max;       /**< Upper limit of zenith angle [degrees] */
   double phi_min;         /**< Lower limit of azimuth angle [degrees] */
   double phi_max;         /**< Upper limit of azimuth angle [degrees] */
   double viewcone_min;    /**< Minimum of VIEWCONE range [degrees]. */
   double viewcone_max;    /**< Maximum of VIEWCONE range [degrees]. */
   double wlen_min;        /**< Lower limit of Cherenkov wavelength range [nm] */
   double wlen_max;        /**< Upper limit of Cherenkov wavelength range [nm] */
   double bunchsize;       /**< Cherenkov bunch size (nominal). */
   
   int num_showers;        /**< Number of showers simulated in run. */
   int iact_options;       /**< Option flags in CORSIKA (VOLUMEDET etc.) */
   int low_E_model;        /**< Low energy interaction model flags. */
   int low_E_detail;       /**< More details on low E interaction model (version etc.) */
   int high_E_model;       /**< High energy interaction model flags. */
   int high_E_detail;      /**< More details on high E interaction model (version etc.) */
   double bfield_bx;       /**< x' component of B field [mT]. */
   double bfield_bz;       /**< z component of B field [mT]. */
   double bfield_rot;      /**< rotation angle mag. N -> geogr. N [degrees]. */
   double start_depth;     /**< Atmospheric depth where primary particle started. */
};

/** Basic parameters of a simulated shower */

struct simulated_shower_parameters
{
   int shower;             /**< Shower number */
   int array;              /**< Array number = shower usage number */
   double energy;          /**< Shower energy [TeV] */
   double azimuth;         /**< Shower direction azimuth [deg] */
   double altitude;        /**< Shower direction altitude above horizon */
   double xcore, ycore, zcore; /**< Shower core position [m] */
   double aweight;         /**< Area weight to be used with non-uniform */
                           /**< core-position sampling [m^2]. */
   double x0;              /**< Atmospheric depth where particle was started [g/cm^2]. */
   double h1int;           /**< Height a.s.l. of first interaction [m]. */
   double core_dist_3d;    /**< Distance of core from reference point */
   double tel_core_dist_3d[MAX_TEL];  /**< Offset of telescopes from shower axis */
   int particle;           /**< Primary particle type [CORSIKA code] */
   int have_longi;         /**< Indicates if vertical profiles were found in data. */
                           /**< If not, the followig numbers should be all zeroes. */
   double step_longi;      /**< Step size of vertical profiles [g/cm**2]. */
   double xmax;            /**< Depth of shower maximum from all particles [g/cm**2] */
   double emax;            /**< Depth of shower maximum from positrons and electrons */
   double cmax;            /**< Depth of maximum of Cherenkov light emission [g/cm**2] */
   double hmax;            /**< Height of shower maximum (from xmax above) [m] a.s.l. */
   double xlongi[1071];    /**< Vertical profile of all particles. */
   double elongi[1071];    /**< Vertical profile of all electrons+positrons. */
   double clongi[1071];    /**< Vertical profile of Cherenkov light emission. */
};

/**  Description of telescope position, array offets and shower parameters. */

struct telescope_array
{
   int ntel;               /**< Number of telescopes simulated per array */
   int max_tel;            /**< Maximum number of telescopes acceptable (MAX_TEL) */
   int narray;             /**< Number of arrays with random shifts per shower */
   double refpos[3];       /**< Reference position with respect to obs. level [cm] */
   double obs_height;      /**< Height of observation level [cm] */
   double xtel[MAX_TEL];   /**< X positions of telescopes ([cm] -> north) */
   double ytel[MAX_TEL];   /**< Y positions of telescopes ([cm] -> west) */
   double ztel[MAX_TEL];   /**< Z positions of telescopes ([cm] -> up) */
   double rtel[MAX_TEL];   /**< Radius of spheres enclosing telescopes [cm] */
   double toff;            /**< Time offset from first interaction to the moment */
                           /**< when the extrapolated primary flying with the vacuum */
                           /**< speed of light would be at the observation level. */
   double xoff[MAX_ARRAY]; /**< X offsets of the randomly shifted arrays [cm] */
   double yoff[MAX_ARRAY]; /**< Y offsets of the randomly shifted arrays [cm] */
   double aweight[MAX_ARRAY]; /**< Area weight for non-uniformly distributed core offsets */
                           /**< (may be 0 when older data with uniform offsets are read). [cm^2] */
   double azimuth;         /**< Nominal azimuth angle of telescope system [deg]. */
   double altitude;        /**< Nominal altitude angle of telescope system [deg]. */
   double source_azimuth;  /**< Azimuth of assumed source. */
   double source_altitude; /**< Altitude of assumed source. */

   int with_aweight;           ///< Is 1 if input data came with weights.

   struct simulated_shower_parameters shower_sim;
   struct mc_options options; /**< File names etc. */
   struct mc_run mc_run;

   int run;
   int event;

   /* ... */
};

/** Parameters describing the telescope optics */

struct telescope_optics
{
   int telescope;           /**< Telescope sequence number */
   /* ... */
};

/** Parameters of a telescope camera (pixels, ...) */

struct pm_camera
{
   int telescope;           /**< Telescope sequence number */
   /* ... */
};

/** Parameters of the electronics of a telescope */

struct camera_electronics
{
   int telescope;           /**< Telescope sequence number */
   int simulated;           /**< Is 1 if the signal simulation was done. */
   
   /* ... */
};

struct linked_string corsika_inputs;

/* ========================== Utility functions ======================= */

/* ------------------- line_point_distance --------------------- */
/**
 *  Distance between a straight line and a point in space
 *
 *  @param  x1,y1,z1  reference point on the line
 *  @param  cx,cy,cz  direction cosines of the line
 *  @param  x,y,z     point in space
 *
 *  @return distance
 *
*/

double line_point_distance (double x1, double y1, double z1, 
   double cx, double cy, double cz,
   double x, double y, double z)
{
   double a, a1, a2, a3, b;
   
   a1 = (y-y1)*cz - (z-z1)*cy;
   a2 = (z-z1)*cx - (x-x1)*cz;
   a3 = (x-x1)*cy - (y-y1)*cx;
   a  = a1*a1 + a2*a2 + a3*a3;
   b = cx*cx + cy*cy + cz*cz;
   if ( a<0. || b<= 0. )
      return -1;
   return sqrt(a/b);
}

/* =================== Main program for the simulation =================== */
/**
 *  Main program of Cherenkov telescope simulation.
*/

int main(int argc, char **argv)
{
   IO_BUFFER *iobuf;
   IO_ITEM_HEADER item_header, sub_item_header, block_header;
   real runh[273], rune[273], evth[273], evte[273];

   /* Some data structures suitably declared to hold data specific */
   /* to the whole telescope array and optics, cameras, and electronics */
   /* of the individual telescopes. */ 
   static struct telescope_array array;
   static struct telescope_optics tel_optics[MAX_TEL];
   struct telescope_optics *optics;
   static struct pm_camera camera[MAX_TEL];
   struct pm_camera *cam;
   static struct camera_electronics electronics[MAX_TEL];
   struct camera_electronics *el;

   double distance;
   int nbunches;
   int itc, itel, iarray, jarray, ibunch;
   int lambda;
   double photons;
   double wl_bunch, airmass, cx, cy, cz, prob;
   double px, py, pz;
   double tel_dist, tel_delay;
   const char *input_fname = NULL;
   FILE *data_file;
   static double power_diff, event_weight, elow;
   static struct bunch bunches[MAX_BUNCHES];
   static int particle_type;
   static double primary_energy;
   static double wl_lower_limit, wl_upper_limit;
   int run = -1, event = -1;
   double alt = -90., az = 0.;
   static double power_law = 2.7;
   double quantum_efficiency[1000], mirror_reflectivity[1000];
   static double plongi[9][1071]; /* Corsika particle longitudinal distributions */
   static double tlongi[1071];    /* Corresponding atmospheric thicknesses [g/cm**2] */
   static double thickstep = 0.;  /* [g/cm**2] */
   static double awt = 0.;
   static int nthick = 0;
   static int have_longi = 0;
   static int have_atm_profile = 0;
   int fill_runheader = 0;
   int tel_individual = 0;
   double toffset;

   /* ... Declare other variables required ... */

   array.mc_run.atmosphere = -1; /* Not known yet */

   /* ... Initialize configuration of optics, camera, and electronics ... */
   
      /* Trivial mirror reflectivity and quantum efficiency */
      for ( lambda = 200; lambda <= 999; lambda++ )
      {
         mirror_reflectivity[lambda] = 0.8;
         quantum_efficiency[lambda] = 
            0.25*exp(-0.5*(lambda-400.)*(lambda-400.)/(100.*100.));
      }

   /* ... Initialize random number generator ... */

   /* ... Initialize histograms ... */

   /* ... Simulate calibration procedure ... */

   /* I/O buffer for input needed */
   if ( (iobuf = allocate_io_buffer(0)) == NULL )
   {
      fprintf(stderr,"Input I/O buffer not allocated\n");
      exit(1);
   }
   array.options.iobuf_max = 20000000;
   if ( getenv("CORSIKA_IO_BUFFER") != 0 )
   {
      char *s = getenv("CORSIKA_IO_BUFFER");
      long nb = atol(s);
      long bs = 1;
      if ( strstr(s,"MiB") != NULL )
         bs = 1024L*1024L;
      else if ( strstr(s,"GiB") != NULL )
         bs = 1024L*1024L*1024L;
      else if ( strstr(s,"M") != NULL || strstr(s,"MB") != NULL || 
           (nb < 64000 && *s == '\0') )
         bs = 1000000L;
      else if ( strstr(s,"G") != NULL || strstr(s,"GB") != NULL )
         bs = 1000000000L;
      if ( sizeof(long) <= 4 && nb*(bs/1000000L) > 2147 )
      {
         fprintf(stderr,"Requested buffer size is too large for this system.\n");
         nb = 2147;
         bs = 1000000L;
      }
      if ( nb*bs > array.options.iobuf_max )
         array.options.iobuf_max = nb*bs;
      printf("Adjusting maximum I/O buffer size to %ld bytes\n",
         array.options.iobuf_max);
   }
   iobuf->max_length = array.options.iobuf_max;
   
   if ( argc > 1 )
      input_fname = argv[1];

   /* Start the big loop over all input files */
   for ( /* ... */ ; input_fname != NULL;
         /* ... loop over file names on command line or config file ... */ )
   {
    array.options.input_fname = input_fname;
    if ( strcmp(input_fname,"-") == 0 )
    {
       printf("Input from standard input.\n");
       data_file = stdin;
    }
    else
    {
       printf("Input file: %s\n",input_fname);
       if ( (data_file = fileopen(input_fname,"r")) == NULL )
       {
	  perror(input_fname);
          argc--;
          argv++;
          if ( argc > 1 )
             input_fname = argv[1];
          else
             input_fname = NULL;
	  continue;
       }
    }

    iobuf->input_file = data_file;

    for(;;) /* Loop over all data in the input file */
    {
      optics = NULL;
      cam = NULL;
      el = NULL;

      /* Find and read the next block of data. */
      /* In case of problems with the data, just give up. */
      if ( find_io_block(iobuf,&block_header) != 0 )
         break;
      if ( read_io_block(iobuf,&block_header) != 0 )
         break;

      /* What did we actually get? */
      switch ( block_header.type )
      {
         /* CORSIKA run header */
         case IO_TYPE_MC_RUNH:
            read_tel_block(iobuf,IO_TYPE_MC_RUNH,runh,273);
            { int nht = runh[4];
              if ( nht>0 && nht <= 10 )
                array.obs_height = runh[4+nht];
              else
                array.obs_height = -100;
            }
            run = array.run = array.mc_run.run = (int) runh[1];
	    array.mc_run.num_showers = 0;
            array.mc_run.corsika_version = (int) (runh[3]*1000.+0.5);
            printf("Run %d: observation level is at %6.1f m\n",
                 run,0.01*array.obs_height);
            airlightspeed = 29.9792458 / Nair(1e-5*array.obs_height);
            if ( power_law > 0. )
               power_law *= -1.;
            power_diff = power_law - runh[15];
            elow = runh[16];
            printf(
           "Events created between %5.3f and %5.3f TeV following a power law\n",
               (double)runh[16]/1e3,(double)runh[17]/1e3);
            printf("of E^%5.2f are now weighted by E^%5.2f\n",
               (double)runh[15],power_diff);
	    /* CORSIKA run information in run header */
	    array.mc_run.height = array.obs_height*0.01;
	    array.mc_run.e_min = runh[16]*0.001;
	    array.mc_run.e_max = runh[17]*0.001;
	    array.mc_run.slope = runh[15];
	    /* Further information has to wait for event header */
	    array.mc_run.radius = array.mc_run.radius1 = array.mc_run.radius2 = 0.;
	    array.mc_run.num_arrays = 0;
	    array.mc_run.theta_min = array.mc_run.theta_max = -1.;
	    array.mc_run.phi_min = array.mc_run.phi_max = -1.;
	    array.mc_run.wlen_min = array.mc_run.wlen_max = 0.;
	    /* ... Update your configuration accordingly ... */

	    fill_runheader = 1;
            break;


      	 /* CORSIKA inputs */
	 case IO_TYPE_MC_INPUTCFG:
	    read_input_lines(iobuf,&corsika_inputs);
	    if ( corsika_inputs.text != NULL )
	    {
	       struct linked_string *xl, *xln;
	       printf("\nCORSIKA was run with the following input lines:\n");
	       for (xl = &corsika_inputs; xl!=NULL; xl=xln)
	       {
	          /* Unfortunately the core distance range is not in the */
		  /* normal CORSIKA header blocks. Extract it from the input. */
	          if ( strncmp(xl->text,"CSCAT",5) == 0 &&
		       (xl->text[5] == ' ' || xl->text[5] == '\t') )
		  {
		     int nr;
		     double r1, r2;
		     if ( sscanf(xl->text+6,"%d %lf %lf", &nr, &r1, &r2) == 3 )
		     {
		     	array.mc_run.radius1 = 0.01 * r1;
		     	array.mc_run.radius2 = 0.01 * r2;
			if ( r2 == 0. )
                        {
			   array.mc_run.radius = 0.01 * r1;
                           array.mc_run.area = M_PI*array.mc_run.radius*array.mc_run.radius;
                        }
                        else
                           array.mc_run.area = 4.*array.mc_run.radius1*array.mc_run.radius2;
		     }
		  }
		  else if ( strncmp(xl->text,"NSHOW",5) == 0 &&
		       (xl->text[5] == ' ' || xl->text[5] == '\t') )
                  {
                     int ns;
		     sscanf(xl->text+6,"%d", &ns);
		     if ( ns != array.mc_run.num_showers && ns > 0 )
                        array.mc_run.num_showers = ns;
                  }
		  
		  printf("   %s\n",xl->text);
		  free(xl->text);
		  xl->text = NULL;
		  xln = xl->next;
		  xl->next = NULL;
		  if ( xl != &corsika_inputs )
		     free(xl);
	       }
	       fflush(stdout);
	    }
	    break;

         /* Telescope positions (relative positions in array) */
         case IO_TYPE_MC_TELPOS:
            array.max_tel = MAX_TEL;
            read_tel_pos(iobuf,MAX_TEL,&array.ntel,array.xtel,array.ytel,
                array.ztel,array.rtel);
            printf("\nSimulated telescope array:\n");
            for (itel=0; itel<array.ntel; itel++)
               printf(
            "   Telescope %d at x=%6.2f m, y=%6.2f m, z=%6.2f m with r=%5.2f m\n",
               camera[itel].telescope,0.01*array.xtel[itel],
               0.01*array.ytel[itel],0.01*array.ztel[itel],
               0.01*array.rtel[itel]);
            printf(
            "Array viewing direction: azimuth=%6.2f deg, altitude=%6.2f deg\n\n",
               array.azimuth,array.altitude);
	    /* ... Adapt your configuration accordingly ... */
            break;

         /* CORSIKA event header */
         case IO_TYPE_MC_EVTH:
            read_tel_block(iobuf,IO_TYPE_MC_EVTH,evth,273);
//            event = evth[1];
            array.shower_sim.shower = evth[1];
            array.shower_sim.array = -1;
            wl_lower_limit = evth[95];
            wl_upper_limit = evth[96];
            primary_energy = evth[3];
	    if ( !have_atm_profile )
	    {
	       int iatmo = (int)(evth[76]/1000+0.5);
	       if ( iatmo <= 0 )
	          iatmo = 6; /* US standard atmosphere */
	       atmset_(&iatmo,&array.obs_height);
	       have_atm_profile = 1;
               array.mc_run.atmosphere = iatmo;
	    }
            array.shower_sim.energy = 0.001 * primary_energy; /* in TeV */
            array.shower_sim.x0 = evth[4];
            /* Note evth[6] is negative if time starts at top of atmosphere. */
            array.shower_sim.h1int = 0.01 * fabs(evth[6]); /* in meters */
	    array.shower_sim.xmax = array.shower_sim.emax = 
	       array.shower_sim.cmax = 0.;
	    array.shower_sim.hmax = 0.;
            particle_type = Nint(evth[2]);
            /* If the time is counted since the primary entered the atmosphere, */
            /* this is indicated by a negative number in the height of the first */
            /* interaction. */
            if ( evth[6] < 0. )
            {
               double t = 0.;
               toffset = (heigh_(&t)-array.obs_height) / cos(evth[10]) / 29.9792458;
            }
            else /* Time is counted since first interaction. */
               toffset = (evth[6]-array.obs_height) / cos(evth[10]) / 29.9792458;
            /* Event weight is now with respect to a 1 TeV shower. */
            event_weight = pow(array.shower_sim.energy,power_diff);
            printf(
            "Event %d: particle type %d with energy %5.2f TeV (weight %5.3f),\n",
                (int)evth[1],particle_type,0.001*primary_energy,event_weight);
            alt = 90. - (180./M_PI)*evth[10];
            az  = 180. - (180./M_PI)*(evth[11]-evth[92]);
            az -= floor(az/360.) * 360.;
            printf("   zenith angle %4.2f deg, azimuth %4.2f deg\n",
               90.-alt, az);

	    have_longi = 0;

	    if ( fill_runheader )
	    {
               fill_runheader = 0;

	       array.mc_run.num_arrays = (array.narray > 0 ? array.narray :
	          (int) (evth[97]+0.5));

	       array.mc_run.theta_min = evth[80];
	       array.mc_run.theta_max = evth[81];
	       array.mc_run.phi_max = 180. - (evth[82]-evth[92]);
	       array.mc_run.phi_min = 180. - (evth[83]-evth[92]);

	       array.mc_run.viewcone_min = evth[152];
	       array.mc_run.viewcone_max = evth[153];
               if ( array.source_altitude == 0. )
               {
                  /* If unspecified in configuration use center of simulation. */
                  array.source_altitude = 90. - 0.5*(array.mc_run.theta_min +
                     array.mc_run.theta_max);
                  array.source_azimuth = 0.5*(array.mc_run.phi_min +
                     array.mc_run.phi_max);
                  printf("Source direction set to Az = %5.1f deg, Alt = %5.1f deg.\n",
                     array.source_azimuth, array.source_altitude);
               }

	       array.mc_run.bunchsize = evth[84];
	       array.mc_run.wlen_min = evth[95];
	       array.mc_run.wlen_max = evth[96];

	       array.mc_run.atmosphere = ((int)(evth[76]+0.5)) >> 10;
	       atmset_(&array.mc_run.atmosphere,&array.obs_height);
               if ( array.mc_run.atmosphere > 0 )
	          have_atm_profile = 1;
               array.mc_run.iact_options = ((int)(evth[76]+0.5)) & 0x3ff;
               array.mc_run.low_E_model = ((int)(evth[74]+0.5));
               array.mc_run.high_E_model = ((int)(evth[75]+0.5));
               array.mc_run.low_E_detail = array.mc_run.high_E_detail = 0;
               if ( array.mc_run.high_E_model == 3 ) /* QGSJET */
                  array.mc_run.high_E_detail = 
                        ((int)(evth[140]+0.5)) + /* 1: QGSJETOLD, 2: QGSJET01c, 3: QGSJET-II */
                        100 * ((int)(evth[141]+0.5)); /* Cross section flag */
               else if ( array.mc_run.high_E_model == 2 ) /* SIBYLL */
                  array.mc_run.high_E_detail = 
                        ((int)(evth[138]+0.5)) +  /* 1: version 1.6, 2: version 2.1 */
                        100 * ((int)(evth[139]+0.5)); /* Cross section flag */
               else if ( array.mc_run.high_E_model == 4 ) /* DPMJET */
                  array.mc_run.high_E_detail = 
                        ((int)(evth[142]+0.5)) + 
                        100 * ((int)(evth[143]+0.5));
               else if ( array.mc_run.high_E_model == 1  /* VENUS */ ||
                         array.mc_run.high_E_model == 5  /* NeXus */ ||
                         array.mc_run.high_E_model == 6  /* EPOS */ )
                  array.mc_run.high_E_detail =
                        100 * ((int)(evth[144]+0.5));

               printf("\nCORSIKA/IACT interface flags:\n");
               if ( (array.mc_run.iact_options & 0x20) != 0 )
                  printf("CORSIKA was compiled with VOLUMEDET option.\n");
               else
                  printf("CORSIKA was compiled without VOLUMEDET option.\n");
               if ( (array.mc_run.iact_options & 0x80) != 0 )
                  printf("CORSIKA/IACT interface supported the VOLUMEDET option.\n");
               if ( (array.mc_run.iact_options & 0x40) != 0 )
                  printf("CORSIKA was compiled with CURVED option.\n");
               if ( (array.mc_run.iact_options & 0x04) != 0 )
                  printf("CORSIKA was compiled with CEFFIC option.\n");
               if ( (array.mc_run.iact_options & 0x08) != 0 )
                  printf("CORSIKA was compiled with ATMEXT option.\n");
               if ( (array.mc_run.iact_options & 0x10) != 0 )
                  printf("CORSIKA ATMEXT option used with refraction.\n");
               printf("\nCORSIKA interaction model flags:\n");
               if ( array.mc_run.low_E_model == 1 )
                  printf("CORSIKA low-energy interactions with GHEISHA.\n");
               else if ( array.mc_run.low_E_model == 2 )
                  printf("CORSIKA low-energy interactions with URQMD.\n");
               else if ( array.mc_run.low_E_model == 3 )
                  printf("CORSIKA low-energy interactions with FLUKA.\n");
               if ( array.mc_run.high_E_model == 1 )
                  printf("CORSIKA high-energy interactions with VENUS.\n");
               else if ( array.mc_run.high_E_model == 2 )
                  printf("CORSIKA high-energy interactions with SIBYLL%s.\n",
                    array.mc_run.high_E_detail%100 == 1 ? " 1.6" :
                    array.mc_run.high_E_detail%100 == 2 ? " 2.1" : "" );
               else if ( array.mc_run.high_E_model == 3 )
                  printf("CORSIKA high-energy interactions with QGSJET%s.\n",
                    array.mc_run.high_E_detail%100 == 1 ? "OLD" :
                    array.mc_run.high_E_detail%100 == 2 ? "01c" : 
                    array.mc_run.high_E_detail%100 == 3 ? "-II" : "");
               else if ( array.mc_run.high_E_model == 4 )
                  printf("CORSIKA high-energy interactions with DPMJET.\n");
               else if ( array.mc_run.high_E_model == 5 )
                  printf("CORSIKA high-energy interactions with NEXUS.\n");
               else if ( array.mc_run.high_E_model == 6 )
                  printf("CORSIKA high-energy interactions with EPOS.\n");
               printf("\n");

	       array.mc_run.bfield_bx = evth[70];
	       array.mc_run.bfield_bz = evth[71];
	       array.mc_run.bfield_rot = (180./M_PI) * evth[92];
	       
	       array.mc_run.start_depth = evth[4];
	    }

            array.shower_sim.azimuth = az;
            array.shower_sim.altitude = alt;
	    array.shower_sim.particle = particle_type;

            clear_shower_extra_parameters(NULL);

            break;

         /* Offsets of telescope array instances for the following event */
         case IO_TYPE_MC_TELOFF:
            read_tel_offset(iobuf,MAX_ARRAY,&array.narray,
                &array.toff,array.xoff,array.yoff);
            toffset = array.toff; /* Should be about the same again as above */
            /* Fill in area weights for older data which is always uniform. */
            array.with_aweight = array.options.always_with_aweight;
            for (jarray=0; jarray<array.narray; jarray++)
            {
               if ( array.aweight[jarray] == 0. )
                  array.aweight[jarray] = array.mc_run.area*1e4 / (double) array.narray;
               else if ( array.with_aweight == 0 )
                  array.with_aweight = 1;
            }
            if ( array.with_aweight < 0 )
               array.with_aweight = 0.; /* Forcing data to be written without area weights. */

      	    array.mc_run.num_arrays = array.narray;
            if ( array.narray == 1 )
               printf("Each shower is used only once.\n");
            else
               printf("Each shower is used %d times.\n", array.narray);
            for (iarray=0; iarray<array.narray; iarray++)
               printf("Shower core offset %d: %4.2f m, %4.2f m\n",
                  iarray+1, -0.01*array.xoff[iarray], -0.01*array.yoff[iarray]);
            break;

         /* Extra event-header like parameters which got available during
            shower processing in CORSIKA but precede actual event data. */
         case IO_TYPE_MC_EXTRA_PARAM:
            {
               struct shower_extra_parameters *ep = get_shower_extra_parameters();
               if ( ep != NULL )
               {
                  if ( read_shower_extra_parameters(iobuf,ep) < 0 )
                  {
                     fprintf(stderr,"Error reading extra shower parameters.\n");
                  }
                  else
                  {
                     /* For now just process the additional shower weight.
                        Other parameters are kept in the static place until
                        they get converted for the output. */
                     for (jarray=0; jarray<array.narray; jarray++)
                        array.aweight[jarray] *= ep->weight;
                  }
               }
            }
            break;

         /* Photon data for a complete array (one of perhaps many instances) */
         case IO_TYPE_MC_TELARRAY:
         case IO_TYPE_MC_TELARRAY_HEAD:
            if ( block_header.type == IO_TYPE_MC_TELARRAY )
            {
               begin_read_tel_array(iobuf, &item_header, &iarray);
               tel_individual = 0;
            }
            else
            {
               read_tel_array_head(iobuf, &item_header, &iarray);
               tel_individual = 1;
            }

            /* Relative area weight = current area weight over total area */
            awt = array.aweight[iarray]*1e-4 / array.mc_run.area;

            printf("Now beginning with shower %d as seen from array %d\n",
               event, iarray);
            array.shower_sim.array = iarray;

            array.shower_sim.xcore = -0.01 * array.xoff[iarray]; /* in meters */
            array.shower_sim.ycore = -0.01 * array.yoff[iarray]; /* in meters */
            /* Observation level is now defining z=0.: */
            array.shower_sim.zcore = 0.; /* Note: this is below lowest telescope */

            array.event = array.shower_sim.shower*100+iarray;
            event++;

            array.shower_sim.core_dist_3d = 
               line_point_distance(array.shower_sim.xcore,
                  array.shower_sim.ycore, array.shower_sim.zcore,
                  cx=cos(alt*(M_PI/180.))*cos(az*(M_PI/180.)),
                  cy=-cos(alt*(M_PI/180.))*sin(az*(M_PI/180.)),
                  cz=sin(alt*(M_PI/180.)), 0.01*array.refpos[0],
                  0.01*array.refpos[1], 0.01*array.refpos[2]);
            /* Distances of telescopes from shower axis */
            for (itel=0; itel<array.max_tel; itel++)
               array.shower_sim.tel_core_dist_3d[itel] = 
                  line_point_distance(array.shower_sim.xcore,
                     array.shower_sim.ycore, array.shower_sim.zcore,
                     cx, cy, cz, 0.01*array.xtel[itel],
                     0.01*array.ytel[itel], 0.01*array.ztel[itel]);

            for (itel=0; itel<array.max_tel; itel++)
               electronics[itel].simulated = 0;
            for (itc=0; itc<array.ntel; itc++)
            {
               if ( !tel_individual )
               {
                  sub_item_header.type = IO_TYPE_MC_PHOTONS;
                  if ( search_sub_item(iobuf,&item_header,&sub_item_header) < 0 )
                     break; /* telescope loop */
               }
               else
               {
                  if ( find_io_block(iobuf,&block_header) != 0 )
                     break;
                  if ( read_io_block(iobuf,&block_header) != 0 )
                     break;
                  if ( block_header.type == IO_TYPE_MC_TELARRAY_END )
                  {
                     tel_individual = 0;
                     break;
                  }
                  if ( block_header.type != IO_TYPE_MC_PHOTONS )
                  {
                     fprintf(stderr,
                        "Expected block type %d but found type %lu.\n",
                        IO_TYPE_MC_PHOTONS, block_header.type);
                     break;
                  }
               }
               /* Read the photon bunches for one telescope */
               if (read_tel_photons(iobuf,MAX_BUNCHES,&jarray,&itel,
                     &photons,bunches,&nbunches) < 0)
               {
                  fprintf(stderr,"Error reading %d photon bunches\n",nbunches);
                  if ( nbunches >= MAX_BUNCHES )
                     fprintf(stderr,"You should enlarge the definition of MAX_BUNCHES and re-compile.\n");
                  exit(1); /* Otherwise we may miss all big events */
                  continue;
               }
               if ( jarray != iarray )
               {
                  fprintf(stderr,
                     "Expected to get photon bunches for array %d but got for %d.\n",
                     iarray, jarray);
               }

               if ( itel >= array.max_tel || itel < 0 )
               {
                  fprintf(stderr,
      "Cannot process data for telescope #%d because only %d are configured.\n",
                    itel+1,array.max_tel);
                  continue;
               }
               printf("Telescope %d has %d bunches with %4.2lf photons in total.\n",
                  itel+1, nbunches, photons);

               optics = &tel_optics[itel];
               cam = &camera[itel];
               el = &electronics[itel];

	       /* ... Other telescope-specific initializations ... */

               for ( ibunch=0; ibunch<nbunches; ibunch++ )
               {
                  /* Wavelength of this bunch or 0. if not set yet. */
                  wl_bunch = bunches[ibunch].lambda;
                  cx = bunches[ibunch].cx;
                  cy = bunches[ibunch].cy;
                  cz = -1.*sqrt(1.-cx*cx-cy*cy); /* direction is downwards */
                  /* Use secans(zenith angle) for airmass, */
                  /* i.e. assume a plane atmosphere. */
                  airmass = -1./cz;
                  /* Distance between point of emission and */
                  /* the CORSIKA observation level */
                  distance = (bunches[ibunch].zem-array.obs_height) * airmass;
                  /* Distance between CORSIKA observation level and */
                  /* telescope fixed position. */
                  tel_dist = array.ztel[itel] * airmass;
                  /* Position where photon hits telescope level. */
                  /* This level is at ztel in the CORSIKA frame. */
                  px = bunches[ibunch].x + tel_dist*cx;
                  py = bunches[ibunch].y + tel_dist*cy;
                  pz = tel_dist*cz;
                  /* Note that, although tracing starts at the CORSIKA */
                  /* level, the bunch time corresponds to the crossing */
                  /* of the telescope level. */
                  tel_delay = tel_dist / airlightspeed;
		  /* Note also that the photon bunch might be created */
		  /* behind the telescope mirror. Check in raytracing. */

                  for (; bunches[ibunch].photons>0; bunches[ibunch].photons-=1.)
                  {
                     if ( wl_bunch == 0. )
                        /* According to 1./lambda^2 distribution */
                        lambda = 1./(1./wl_lower_limit-RandFlat()*
                          (1./wl_lower_limit-1./wl_upper_limit));
		     else if ( wl_bunch < 0. )
		        /* This indicates that quantum efficiency, mirror */
			/* reflectivity, and atmospheric transmission */
			/* have already been applied in CORSIKA (which */
			/* was CMZ extracted then with the CEFFIC option). */
			lambda = -1.;
                     else 
                        /* Wavelength already generated in Corsika */
                        lambda = (int)wl_bunch;

                     if ( lambda >= 1000 )
                        continue;
                     else if ( lambda >= 0 )
		     {
                	/* Detection probability in most optimistic case: */
                	prob = atmospheric_transmission(lambda,
                        	 bunches[ibunch].zem, airmass) *
                               quantum_efficiency[lambda] *
                               mirror_reflectivity[lambda];
		     }
		     else
                     {
		     	/* CORSIKA was compiled with CEFFIC option */
			static int first_warn = 0;
			if ( !first_warn )
			{
			   fprintf(stderr,
                              "\n\nBeware: The data have been produced by "
                              "a CORSIKA version with CEFFIC option.\n"
			      "No atmospheric transmission, mirror reflectivity,"
			      " and quantum efficiency will be applied!\n\n");
			   sleep(2); // Make sure it can be seen.
			   first_warn = 1;
			}
		     	prob = bunches[ibunch].photons; /* Normally: 1. */
                     }

                     if ( bunches[ibunch].photons < 1. )
                        prob *= bunches[ibunch].photons;

                     if ( prob < 1. )
                     	if ( RandFlat() > prob )
                           continue;
                     
                     /*
                     if ( lambda < 0 )
                        printf("Processing photo-electron from CORSIKA CEFFIC option.\n");
                     else
                        printf("Detectable photon of %d nm wavelength.\n", lambda);
                     */

                     /* ... Trace photon through telescope to camera ... */

                     /* ... See if a camera pixel was hit ... */

		     /* ... Collect photo-electrons for that pixel ... */
		  }
	       }

               /* ... Simulate PM signals in FADC and discriminators ... */

               /* ... Simulate the telescope trigger ... */

            } /* End of loop over telescopes */

            if ( tel_individual )
            {
               if ( find_io_block(iobuf,&block_header) != 0 )
                  break;
               if ( read_io_block(iobuf,&block_header) != 0 )
                  break;
               if ( block_header.type == IO_TYPE_MC_TELARRAY_END )
                  tel_individual = 0;
               else
               {
                  fprintf(stderr,
                     "Expected block type %d but found type %lu.\n",
                     IO_TYPE_MC_TELARRAY_END, block_header.type);
                  fprintf(stderr,"Telescope array end block missing after "
                     "reading telescope data individually.\n");
                  break;
               }
            }
            
            /* ... Enough telescopes to trigger the array? ... */

            /* ... Filling of histograms etc. for one array instance ... */
	    /* Note: data structures are reused for next instance. */

            end_read_tel_array(iobuf, &item_header);
            break;

         /* CORSIKA longitudinal distributions: */
         case IO_TYPE_MC_LONGI:
	   {  int type = block_header.ident%10;
	      int np=0, ndim=1071, np_max=9, ev=0, j;
              int nx = sizeof(array.shower_sim.xlongi) /
                       sizeof(array.shower_sim.xlongi[0]);

              array.shower_sim.have_longi = 0;

	      if ( type == 1 )
	      {
	        read_shower_longitudinal(iobuf,&ev,&type,&plongi[0][0],ndim,&np,
		  &nthick,&thickstep,np_max);
	        if ( nthick <= 1 ) /* Long. dist. not enabled in CORSIKA */
                {
		   continue; /* with main data loop */
                }
	        for (j=0; j<nthick && j<nx; j++)
		{
	          tlongi[j] = thickstep * (double)j;
		  array.shower_sim.xlongi[j] = plongi[6][j]; /* all charged */
		  array.shower_sim.elongi[j] = plongi[1][j] + plongi[2][j]; /* e+ + e- */
		  array.shower_sim.clongi[j] = plongi[8][j]; /* light emission */
	        }

	        array.shower_sim.have_longi = nthick;
                array.shower_sim.step_longi = thickstep;
		array.shower_sim.xmax = 
                  find_max_pos(array.shower_sim.xlongi,nthick) * thickstep;
	        array.shower_sim.hmax = heighx_(&array.shower_sim.xmax) * 0.01;
		array.shower_sim.emax = 
                  find_max_pos(array.shower_sim.elongi,nthick) * thickstep;
		array.shower_sim.cmax = 
                  find_max_pos(array.shower_sim.clongi,nthick) * thickstep;
#ifdef DEBUG_TEST_ALL
                printf("Longitudinal profile with %d points has maximum at %3.1f/%3.1f/%3.1f g/cm**2\n",
                  nthick, array.shower_sim.xmax, array.shower_sim.emax, array.shower_sim.cmax);
#endif
	      }
	    }
	    break;

         /* CORSIKA event trailer */
         case IO_TYPE_MC_EVTE:
            read_tel_block(iobuf,IO_TYPE_MC_EVTE,evte,273);
	    /* All array instances for this shower are finished */
            break;

         /* CORSIKA run trailer */
         case IO_TYPE_MC_RUNE:
            read_tel_block(iobuf,IO_TYPE_MC_RUNE,rune,273);
            break;

         /* Unknown / any other material */
         default:
            fprintf(stderr,"Unknown block type %ld is ignored.\n",
               block_header.type);
            break;
      } /* End of switch over all input data types */
    } /* End of loop over all data in the input file */
    if ( iobuf->input_file != stdin && iobuf->input_file != NULL )
      fileclose(iobuf->input_file);
    iobuf->input_file = NULL;
    
    fprintf(stderr,"End of input file %s\n", array.options.input_fname);
    argc--;
    argv++;
    if ( argc > 1 )
       input_fname = argv[1];
    else
       input_fname = NULL;
   } /* End of big loop over input files */

   /* ... Save histograms ... */
   
   /* ... Save random number generator status ... */

   return 0;
}
